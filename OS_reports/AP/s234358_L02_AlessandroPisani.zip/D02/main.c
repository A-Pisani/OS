#include <stdio.h>
#include <stdlib.h>
#define N 100+1

int main(int argc, char **argv)
{
    if(argc!=2){
       fprintf(stderr, "Wrong number of parameter\n");
       exit(1);
    }
    char word[N];
    FILE *fp;
    int count=0;
    fp = fopen(argv[1], "r");
    if(fp==NULL){
        fprintf(stderr, "E\n");
        exit(1);
    }
    while(fscanf(fp,"%s",word)!=EOF){
        count++;
    }
    fprintf(stdout, "The total umber of words is: %d", count);
    return 0;
}
