#!/bin/bash
mkdir ex1 
cd ex1 
mkdir bin 
mkdir src 
mkdir test 
cd src 
mkdir include 
mkdir lib 
cd .. 
cd test 
mkdir result 
cd .. 
cd .. 
mkdir -p ex1/test/result 