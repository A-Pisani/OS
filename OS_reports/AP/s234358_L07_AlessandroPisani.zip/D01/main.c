#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *tfunction(void *);

int main(int argc, char **argv)
{
    if(argc!=2){
       fprintf(stderr,"Wrong number of parameters!\n");
       exit(EXIT_FAILURE);
    }
    int n=atoi(argv[1]);
    void *status;
    pthread_t tid;

    pthread_create(&tid,NULL,tfunction,(void *) &n);

    pthread_join(tid,&status);

    long int stat=status;
    fprintf(stdout,"\n%ld",stat);
    fprintf(stdout,"\nJoined thread %lu\n",tid);

    return 0;
}

void *tfunction(void *par){
   long int d;
   int *tmp;
   tmp=(int *)par;
   int n=*tmp;
   void *exitStat;
   pthread_t self;
   self = pthread_self();

   //print TID
   fprintf(stdout,"Created thread %lu\n",self);
   //sleep n seconds
   sleep(n);
   fprintf(stdout,"Please digit a number that will be my exit status: ");
   fscanf(stdin,"%ld",&d);
   //pthread exit
   pthread_exit(d);
}
