#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include <sys/types.h>

typedef struct height_s height_t;
struct height_s{
   int current_h;   //level of the tree (current)
   int final_h;     //max height of the tree
   int threadID;    //current threadID
   height_t *father;//father of the current thread
};
void *tree_r(void *h);
int n;

int main(int argc, char **argv)
{
    setbuf(stdout,0);
    if(argc!=2){
       fprintf(stderr, "Error in the command line\n");
       exit(EXIT_FAILURE);
    }
    n= atoi(argv[1]);
    height_t *h;
    h=(height_t *)malloc(sizeof(height_t));
    if(h==NULL){
       fprintf(stderr, "Error in struct malloc\n");
       exit(EXIT_FAILURE);
    }
    h->current_h =0;
    h->threadID=pthread_self();
    h->father=NULL;

    tree_r((void *)h);



    return 0;
}

void *tree_r(void *h){
    pthread_t tidL, tidR, tid;
    height_t *hh=(height_t *)h;      //cast of height_t hh

   //termination condition
   if(hh->current_h>=n){
      fprintf(stdout,"%lu\n",pthread_self());
      pthread_exit(NULL);
   }

    hh->current_h = hh->current_h+1;
    hh->threadID=pthread_self();
    height_t *workerL, *workerR;
    //allocating left worker
    workerL=(height_t *)malloc(sizeof(height_t));
    if(workerL==NULL){
       fprintf(stderr, "Error in struct malloc\n");
       exit(EXIT_FAILURE);
    }
    workerL->current_h =hh->current_h;
    workerL->father=hh;
    //allocating right worker
    workerR=(height_t *)malloc(sizeof(height_t));
    if(workerR==NULL){
       fprintf(stderr, "Error in struct malloc\n");
       exit(EXIT_FAILURE);
    }
    workerR->current_h =hh->current_h;
    workerR->father=hh;




    pthread_create(&tidL,NULL,tree_r,(void *)workerL);
    pthread_create(&tidR,NULL,tree_r,(void *)workerR);
    pthread_join(tidR,NULL);
    pthread_join(tidL,NULL);
    free(workerL);
    free(workerR);

    pthread_exit(NULL);
}
