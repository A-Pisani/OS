#!/bin/bash

filename=$1
if [ -z $filename ]
then
  filename=/dev/stdin
fi

declare -A array

for word in $(cat $filename); do
  freq=${array[$word]}
  array[$word]=$((freq+1))
done

for word in ${!array[*]}; do
  echo "$word ${array[$word]}"
done

unset array
