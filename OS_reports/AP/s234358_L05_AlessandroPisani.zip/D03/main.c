#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char **argv)
{
    if(argc!=2){
       fprintf(stdout,"Wrong number of parameters!\n");
       exit(1);
    }

    char *cmd[]={
      "sort",
      "-n","-o", "F1.txt", "F1.txt",
      NULL};
    char *cmd2[]={
      "sort","-n", "-o", "F2.txt", "F2.txt",
      NULL};

    int i;
    int sysVal;
    int k;
    int x;
    pid_t pid,pid1;
    k=atoi(argv[1]);
    FILE *fo1, *fo2,*fb1,*fb2, *f_end;

    fo1=fopen("F1.txt","w");
    fo2=fopen("F2.txt","w");


    if(fo1==NULL ||fo2==NULL){
       fprintf(stdout,"Error opening file!\n");
       exit(2);
    }

    srand(234362);
    for(i=0;i<k;i++){
       fprintf(fo2,"%d\n",rand()%1000000+1);
    }
    for(i=0;i<k;i++){
       fprintf(fo1,"%d\n",rand()%1000000+1);
    }

    if(fflush(fo1)!=0||fflush(fo2)!=0){
       fprintf(stdout,"Error in fflush!\n");
       exit(3);
    }

    pid=fork();
    if(pid==0){
       if(fork()==0){
          if(execv("/usr/bin/sort",cmd)==-1)
            fprintf(stdout,"error in execv\n");
          system("ps");
          exit(0);
       }
    }else{
        pid1=waitpid(pid,&sysVal,0);
        if(fork()==0){
         if(execv("/usr/bin/sort",cmd2)==-1)
            fprintf(stdout,"error in execv\n");
          exit(0);
        }
    }
    fclose(fo1);
    fclose(fo2);
    fo1=fopen("F1.txt","r");
    fo2=fopen("F2.txt","r");
    fb1=fopen("F1.bin","w");
    fb2=fopen("F2.bin","w");

    while(1){
    fscanf(fo1, "%d\n", &x);
    fwrite(&x, 1, sizeof(int), fb1);
        if(feof(fo1))
        break;
    }
    while(1){
    fscanf(fo2, "%d\n", &x);
    fwrite(&x, 1, sizeof(int), fb2);
        if(feof(fo2))
        break;
    }
    rewind(fo1);
    rewind(fo2);
    fclose(fb1);
    fclose(fb2);

    fb1=fopen("F1.bin","w");
    fb2=fopen("F2.bin","w");
    f_end=fopen("F12.sorted","w");

    i=0;
    int j=0;
    int y;

    while(i<k && j<k){
       if(fread(&x, sizeof(int),1,fb1) < fread(&y, sizeof(int),1,fb2)){
          fwrite(&x, 1, sizeof(int), f_end);
          i++;
       }
       else{
          fwrite(&y, 1, sizeof(int), f_end);
          j++;
       }

    }
    // Copy the remaining values of one of the two vectors
    while(i<k){
       fread(&x, sizeof(int),1,fb1);
       fwrite(&x, 1, sizeof(int), f_end);
       i++;
    }
    while(j<k){
       fread(&y, sizeof(int),1,fb2);
       fwrite(&y, 1, sizeof(int), f_end);
       j++;
    }
    system("rm F1.bin F2.bin");


    return 0;
}
