#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <signal.h>

void manager (int sig);
void manager1 (int sig);
int main(int argc, char **argv)
{
    if(argc!=2){
       fprintf(stderr,"Wrong number of parameters!\n");
       exit(EXIT_FAILURE);
    }
    srand(time(NULL));
    int r, r2;
    r2=10+rand()%10+1;
    int i=0;
    int j=0;
    char vec[1000];

    fprintf(stdout,"variable r2 is: %d\n",r2);
    fflush(stdout);

    if(fork()==0){
      for(int i=0;i<r2+6;i++){
         r=rand()%10+1;
         sleep(r);
         kill(getppid(),SIGUSR1);
      }
      exit(i);
    }else{
       FILE *fp;
       fp=fopen(argv[1],"r");
       if(fp == NULL){
        fprintf(stderr, "Error in opening the file\n");
        exit(EXIT_FAILURE);
       }
    while(1){
       if(j>=r2 && j<r2+5){
          if(signal(SIGUSR1,manager)==SIG_ERR){
          fprintf(stdout,"err");
          }
          fprintf(stdout,"signal SIGUSR1 received and default behaviour skipped\n");
          j++;
          continue;
       }else if(j==r2+5){
          signal(SIGUSR1,manager1);
          fprintf(stdout,"signal SIGUSR1 number %d received and processes terminated\n",j);
          exit(1);
       }else if(j%2==0){
          signal(SIGUSR1,manager);
          fprintf(stdout,"signal SIGUSR1 received and default behaviour skipped\n");
          j++;
          continue;
       }else{
          signal(SIGUSR1,manager1);
          fprintf(stdout,"signal SIGUSR1 received and default behaviour done\n");
          j++;
       }
       while(fgets(vec,1000,fp)!=NULL){
         fprintf(stdout,"line number: %d \t%s",++i,vec);
         fflush(stdout);
       }
       rewind(fp);
       i=0;
    }
    }

    return 0;
}
void manager (int sig) {
   if (sig==SIGUSR1)
   printf ("Ricevuto SIGUSR1 da manager\n");
   else printf ("Ricevuto %d\n", sig);
   char cmd[100];
   sprintf(cmd,"kill -SIGSTOP %d",getpid());
   system(cmd);
   return;
}
void manager1 (int sig) {
   if (sig==SIGUSR1)
   printf ("Ricevuto SIGUSR1 da manager1\n");
   else printf ("Ricevuto %d\n", sig);
   //pause();
   char cmd[100];
   sprintf(cmd,"kill -SIGCONT %d",getpid());
   sleep(3);
   system(cmd);
   return;
}
