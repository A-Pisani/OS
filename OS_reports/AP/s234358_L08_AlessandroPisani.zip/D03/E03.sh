#!/bin/bash

if [ $# -ne 2 ]
then
   echo "Usage: $0 [file.txt] [product]"
   exit 1
fi


#Solution 3.1
cat $1 | sort -r -k 1 > tmp
cat tmp > $1
rm tmp

#Solution 3.2
cat $1 | sort -n -k 2 > tmp
cat tmp > $1
rm tmp

#Solution 3.3
sum=0
while read field1 field2
do
   if [ $2 = $field1 ]
   then
      let sum=sum+field2
   fi
done < $1 
echo "total quantity for product $2 is $sum"

#Solution 3.4
#cut -d '	' -f 1 $1 | sort | uniq > tmp
#cut -f 1 $1 | sort -u
cut -f 1 $1 | sort | uniq > tmp
tr a-z A-Z < tmp 
rm tmp




exit 0
