#!/bin/bash 


if [ $# -ne 2 ]
then
   echo "Usage: $0 [directory] [output]"
   exit 1
fi

ls -l $1 > tmp
ls -l $1 > tmp

if [ ! -d $1 ]
then
   echo "$1 must be a directory"
   exit 1
else
   while read var1 var2 var3 var4 var5 var6 var7 var8 var9
   do
   #echo "${var9:4:1}"
      if [ -d "$1$var9" ]
      then
         echo "$1$var9 is a directory and has $(ls -l $1$var9 | grep -c ^d ) subdirectories"
         #we could have used instead FIND ---> find $1$var9/* -maxdepth 0 -type d | wc -l
      else 
         echo "$1$var9 is a regular file has dimension: $var5 (in bytes) and has read: ${var1:4:1} and write: ${var1:5:1}  permission"              
      fi
   done < tmp > out
   rm tmp
fi
