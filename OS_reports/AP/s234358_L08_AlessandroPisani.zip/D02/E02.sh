#!/bin/bash

if [ $# -ne 1 ]
then
   echo "Please enter input file"
   read $1
fi

cat $1 | sort -k 1 >$1

exit 0
