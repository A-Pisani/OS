#!/bin/bash

if [ $# -ne 1 ]
then 
   echo "Usage: $0 file.txt"
   exit 1
fi

maxLength=0
currLength=0

while read line
do
 currLength=$(echo -n $line | wc -c)
 if [ $currLength -ge $maxLength ]
 then
  let maxLength=currLength
 fi
done <$1

numberLines=$(cat $1 | wc -l)

echo "maximum length of a line is: $maxLength"
echo "number of lines is: $numberLines"
#count of the longest line through wc
maxLength=$(cat $1 | wc -L)
echo "maximum length of a line counting the newline is: $maxLength"

exit 0
