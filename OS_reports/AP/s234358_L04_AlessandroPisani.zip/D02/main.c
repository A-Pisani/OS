#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/wait.h>

int main()
{
    int n1, n2, r;
    pid_t pid;
    pid_t childPid;
    int statVal;

    pid=fork();
    if(pid!=0){
       srand(time(NULL));
       n1=rand()%100+1;
       fprintf(stdout,"This is variable n1: %d\n",n1);
       sleep(n1);
       childPid=wait(&statVal);
       fprintf(stdout,"Child exit status: %d\n",childPid);
    }else{
       fprintf(stdout,"Child Pid: %d\n",getpid());
       fprintf(stdout,"Parent Pid: %d\n",getppid());
       srand(time(NULL));
       n2=rand()%100+1;
       sleep(n2);
       srand(time(NULL));
       r=rand()%255+1;
       fprintf(stdout,"This is variable r: %d\n", r);
       fprintf(stdout,"Parent Pid: %d\n",getppid());
       exit(r);
    }


    return 0;
}
