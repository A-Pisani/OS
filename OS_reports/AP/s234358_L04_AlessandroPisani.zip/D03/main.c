#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char **argv)
{
    if(argc!=2){
       fprintf(stderr, "Wrong number of parameters!\n");
       exit(1);
    }
    int n;
    int sysVal;
    n=atoi(argv[1]);
    pid_t pid;
    pid_t w;

    int *array;
    array=(int *)malloc(n*sizeof(int));
    if(array==NULL){
       fprintf(stderr, "Error in array dynamic allocation!\n");
       exit(2);
    }
    fprintf(stdout,"Please enter %d values: \n", n);
    for(int i=0;i<n;i++){
       
       fscanf(stdin,"%d",&array[i]);
    }
    fprintf(stdout,"thank you, wait a moment...\n");

    for(int j=n;j>0;j--){
      pid=fork();
      if(pid==0){
         sleep(j);
         return j;
      }
      else{
         w=wait(&sysVal);
         fprintf(stdout,"Process %d with identifier %d has terminated with status: %d\n",n-j,array[n-j],w);
      }
    }

    return 0;
}
