#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

FILE *fp;
int i=1;
char next[2+1]={' ',' ',' '}, thiss[2+1]={' ',' ',' '}, last[2+1]={' ',' ',' '};


static void *GET (void *arg);
static void *UPD (void *arg);
static void *PRINT (void *arg);

int main(int argc, char **argv)
{
    if(argc!=2){
       fprintf(stderr, "Error in the command line\n");
       exit(EXIT_FAILURE);
    }
    fp = fopen(argv[1], "r");
    if(fp == NULL){
       fprintf(stderr, "Error in opening the file\n");
       exit(EXIT_FAILURE);
    }
    pthread_t tGet, tUpd, tPrint;

    while(i==1){
       pthread_create(&tGet, NULL, (void *)GET, (void *)next);
       pthread_create(&tUpd, NULL, (void *)UPD, (void *)thiss);
       pthread_create(&tPrint, NULL, (void *)PRINT, (void *)last);
       pthread_join(tGet, NULL);
       pthread_join(tUpd, NULL);
       pthread_join(tPrint, NULL);

       strcpy(last,thiss);
       strcpy(thiss,next);
    }

    //last two strings processing
       pthread_create(&tUpd, NULL, (void *)UPD, (void *)thiss);
       pthread_create(&tPrint, NULL, (void *)PRINT, (void *)last);
       pthread_join(tGet, NULL);
       pthread_join(tUpd, NULL);
       pthread_join(tPrint, NULL);

       printf("\n");

    return 0;
}

static void *GET (void *arg){
    char *c = (char*) arg;
    i = fscanf(fp, "%2s", c);
    fprintf(fp,"%s",c);
    return NULL;
}
static void *UPD (void *arg){
    char *c = (char*) arg;
    for(int i=0;i<3;i++){
       c[i]=toupper(c[i]);
    }
    return NULL;
}
static void *PRINT (void *arg){
    char *c = (char*) arg;
    printf("%s",c);
    return NULL;
}
