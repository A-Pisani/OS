#!/bin/bash 

gcc -Wall -o ex2 main.c -lm
./ex2

pkill SIGUSR1 ex2
pkill SIGUSR1 ex2
pkill SIGUSR1 ex2
