#!/bin/bash 

while read var1 var2 var3 var4 var5 var6
do
   if [ $var4 = "POST" ]
   then 
      if [ ${var3:1:10} = $2 ]
      then
         for var8 in $*
         do
            if [ $var8 = $var2 ]
            then
               if [ $var6 -eq 200 ]
               then
                  echo "$var1"
                  break
               fi
            fi
         done
      fi
   fi
done < $1 > tmp

cat tmp | sort | uniq 
rm tmp
