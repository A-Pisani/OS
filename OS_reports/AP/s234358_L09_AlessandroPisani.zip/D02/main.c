#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>

int index=0;
int sequence[3]={0};

void USR1 (int);
void USR2 (int);
int check();
int main(){

    if(signal(SIGUSR1,USR1)==SIG_ERR){
       fprintf(stderr,"Error in definition of signal handler USR1\n");
       exit(EXIT_FAILURE);
    }
     if(signal(SIGUSR2,USR2)==SIG_ERR){
       fprintf(stderr,"Error in definition of signal handler USR2\n");
       exit(EXIT_FAILURE);
    }
     if(signal(SIGALRM,SIG_DFL)==SIG_ERR){
       fprintf(stderr,"Error in definition of signal handler of SIGALRM\n");
       exit(EXIT_FAILURE);
    }
    while(1){
       sleep(5);
       if(check()==2){
          return 0;
       }
    }
    return 0;
}

void USR1 (int sig){
   if(sequence[0]==0){
      sequence[0]=1;
   }else if(sequence[1]==0){
      sequence[1]=1;
   }else if(sequence[2]==0){
      sequence[2]=1;
   }else{
      sequence[0]=sequence[1];
      sequence[1]=sequence[2];
      sequence[2]=1;
   }

}
void USR2 (int sig){
   if(sequence[0]==0){
   sequence[0]=2;
   }else if(sequence[1]==0){
      sequence[1]=2;
   }else if(sequence[2]==0){
      sequence[2]=2;
   }else{
      sequence[0]=sequence[1];
      sequence[1]=sequence[2];
      sequence[2]=2;
   }
}
int check(){
   int i = 0;
   if(sequence[0]!=0 && sequence[1]!=0 && sequence[0]!=sequence[1]){
      fprintf(stderr, "Sequence of two different siguser (in position 0-1)\n");
   }else if(sequence[0]!=0 && sequence[1]!=0 && sequence[0]==sequence[1]){
      fprintf(stdout, "Sequence of two equal siguser (in position 0-1)\n");
      i++;
   }
   if(sequence[2]!=0 && sequence[1]!=0 && sequence[2]!=sequence[1]){
      fprintf(stderr, "Sequence of two different siguser (in position 1-2)\n");
   }else if(sequence[2]!=0 && sequence[1]!=0 && sequence[2]==sequence[1]){
      fprintf(stdout, "Sequence of two equal siguser (in position 1-2)\n");
      i++;
   }
   if(i==2){
      fprintf(stdout, "Sequence of three equal siguser\n");
   }
   return i;
}
