#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <unistd.h>
#include <pthread.h>
#define N 10

sem_t *SD;
sem_t *SA;
sem_t *SB;
sem_t *SC;
void *createA();
void *createB();
void *createC();
void *createD();
int main()
{
    setbuf(stdout,0);
    srand(time(NULL));
    SA=(sem_t *)malloc(1*sizeof(sem_t));
    if(SA==NULL){
        fprintf(stderr, "Error in memory allocation");
        exit(EXIT_FAILURE);
    }
    sem_init(SA,0,1);
    SB=(sem_t *)malloc(1*sizeof(sem_t));
    if(SB==NULL){
        fprintf(stderr, "Error in memory allocation");
        exit(EXIT_FAILURE);
    }
    sem_init(SB,0,0);
    SC=(sem_t *)malloc(1*sizeof(sem_t));
    if(SC==NULL){
        fprintf(stderr, "Error in memory allocation");
        exit(EXIT_FAILURE);
    }
    sem_init(SC,0,0);
    SD=(sem_t *)malloc(1*sizeof(sem_t));
    if(SD==NULL){
        fprintf(stderr, "Error in memory allocation");
        exit(EXIT_FAILURE);
    }
    sem_init(SD,0,0);
    pthread_t ta;
    pthread_t tb;
    pthread_t tc;
    pthread_t td;
    pthread_create(&ta,NULL,createA,NULL);
    pthread_create(&tb,NULL,createB,NULL);
    pthread_create(&tc,NULL,createC,NULL);
    pthread_create(&td,NULL,createD,NULL);
    pthread_join(ta,NULL);
    pthread_join(tb,NULL);
    pthread_join(tc,NULL);
    pthread_join(td,NULL);
    sem_destroy(SD);
    sem_destroy(SA);
    sem_destroy(SB);
    sem_destroy(SC);
    return 0;
}
void *createA(){
    int randA;
    for(int i=0;i<N;i++){
    sem_wait(SA);
    srand(time(NULL));
    randA=rand()%1+1;
    sleep(randA);
    printf("A");
    sem_post(SB);
    sem_post(SC);
    }
    pthread_exit(NULL);
}
void *createB(){
int randB;
for(int i=0;i<N;i++){
    sem_wait(SB);
    srand(time(NULL));
    randB=rand()%1+1;
    sleep(randB);
    printf("B");
    sem_post(SD);
    }

    pthread_exit(NULL);
}
void *createC(){
    int randC;
    for(int i=0;i<N;i++){
    sem_wait(SC);
    srand(time(NULL));
    randC=rand()%1+1;
    sleep(randC);
    printf("C");
    sem_post(SD);
    }

    pthread_exit(NULL);
}
void *createD(){
   int randD;
    for(int i=0;i<N;i++){
    sem_wait(SD);
    sem_wait(SD);
    srand(time(NULL));
    randD=rand()%1+1;
    sleep(randD);
    printf("D\n");
    sem_post(SA);
    }

    pthread_exit(NULL);

}
