#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <ctype.h>

int main()
{
    int pipend[2];
    pid_t pid, pid1;
    int sysVal;
    pipe(pipend);
    char str[100];

    setbuf(stdout,0);
    fprintf(stdout,"please write something or press \"end\" to stop\n");
    pid=fork();

    if(pid==0){
           while(1){
              fgets(str,100,stdin);
              write(pipend[1],str,100);
              if(strcmp(str,"end\n")==0)
                exit(0);
              sleep(9);
              fprintf(stdout,"please write something or press \"end\" to stop\n");
           }
    }else{
               pid1=fork();
               if(pid1==0){
                  sleep(2);
                  read(pipend[0],str,100);
               while(strcmp(str,"end\n")!=0){
                sleep(5);
                for(int i=0;i<strlen(str);i++){
                  str[i]=toupper(str[i]);
                }
                fprintf(stdout,"%s\n",str);
                read(pipend[0],str,100);
               }
                fprintf(stdout,"consumer ending\n");
                   exit(0);
               }else{
                waitpid(pid,&sysVal,0);
                waitpid(pid1,&sysVal,0);
               }
        }
        return 0;
    }
