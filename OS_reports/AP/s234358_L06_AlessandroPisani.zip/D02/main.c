#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>

void manager(int sig);

int main(int argc, char** argv) {
    if(argc!=3){
        fprintf(stderr, "Error in the command line");
        exit(EXIT_FAILURE);
    }
    int c = atoi(argv[1]);
    char str [100];
    setbuf(stdout,0);
    sprintf(str,"ls %s > list.txt",argv[2]);
    system(str);
    int i, r=0, counter=0;
    int counter2=0;
    int sysVal;
    char st [100];
    FILE *fp;
    FILE *childf;
    fp=fopen("list.txt","r");
    if(fp == NULL){
        fprintf(stderr, "Error in opening the file\n");
        exit(EXIT_FAILURE);
    }
    int mat[c][2];

    signal(SIGPIPE,SIG_DFL);

    int request_pipe[2];
    pipe(request_pipe);
    int data_pipe[2];
    pipe(data_pipe);
    int answer_pipe[2];
    pipe(answer_pipe);
    int totSor, totDef=0;
    pid_t tempPid;

    pid_t pid;
    char cx;
    pid = fork();
    mat[c-1][0]=pid;
    mat[c-1][1]=0;
    for(i=0; i<(c-1); i++){
        if(pid!=0){
            pid=fork();
            mat[i][0]=pid;
            mat[i][1]=0;
        }
    }
    if(pid){
        while(read(request_pipe[0],&cx,1)){
            if(fscanf(fp,"%s",st)!=EOF){
            counter++;//numero di file sortati (file presenti nella dir)
            write(data_pipe[1],st,100);
            read(answer_pipe[0],st,100);
            sscanf(st,"%d%d",&tempPid,&totSor);
            fprintf(stdout,"%d %d\n",tempPid,totSor);
            for(i=0;i<c;i++){
                if(mat[i][0]==tempPid){
                    mat[i][1]+=totSor;
                }
            }
            totDef += totSor;
            }else{
                break;
            }
        }
        fprintf(stdout,"total number of files sorted %d the total number sum of the lines that have been sorted %d\n",counter,totDef);
        for(i=0;i<c;i++){
            fprintf(stdout,"child %d has sorted %d lines\n",mat[i][0],mat[i][1]);
        }
        //close pipe terminals.
        close(request_pipe[0]);
        // send a SIGPIPE signal to
        for(i=0; i<c; i++){
            kill(mat[i][0],SIGPIPE);
        }
        // wait all children
        for(i=0; i<c; i++){
            wait(&sysVal);
        }
        rewind(fp);
        for(i=0;i<counter;i++){
           fscanf(fp,"%s",st);
           sprintf(str+counter2,"%s%s ",argv[2],st);
           counter2+=strlen(st)+strlen(argv[2])+1;
        }
         fprintf(stdout,"%s\n",str);
         sprintf(st,"sort -m %s > all_sorted.txt ",str);
         fprintf(stdout,"%s\n",st);
         system(st);
    }else{
        while(1){  //work with signals to get out of while when a SIGPIPE is catched
            write(request_pipe[1],&cx, 1);
            read(data_pipe[0],st,100);
            sprintf(str,"sort -o %s%s %s%s",argv[2], st,argv[2], st);
            system(str);
            //sprintf(str,"sort -o %s %s", st, st);
            sprintf(str,"%s%s",argv[2],st);
            childf=fopen(str,"r");
            while(fgets(str,100,childf)!=NULL){
                counter++;
            }
            sprintf(str,"%d %d",getpid(),counter);
            write(answer_pipe[1],str,100);
            counter=0;
        }
    }
    return EXIT_SUCCESS;
}
void manager(int sig){

}
