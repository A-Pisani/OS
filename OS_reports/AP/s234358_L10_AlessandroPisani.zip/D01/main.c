#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char** argv)
{
    if(argc!=2){
       fprintf(stderr,"Wrong number of parameters, Usage: [filename] [n]\n");
       exit(EXIT_FAILURE);
    }
    int n=atoi(argv[1]);
    //setbuf(stdout,0);
    pid_t pid1, pid2;
    int *array;
    array=(int *)malloc((n+1)*sizeof(int));
    if(array==NULL){
       fprintf(stderr,"There's a problem in mem allocation\n");
       exit(EXIT_FAILURE);
    }
    array[0]=1;

    for(int i=0;i<n;i++){
          if(fork()){
            if(fork()){ //father process
              return 0;
            }else{ //second child
               array[i+1]=array[i]*2+1;
            }
          }else{ //first child
            array[i+1]=array[i]*2;
          }
    }

    fprintf(stdout,"Process tree: ");
    for(int i=0;i<n+1;i++){
       fprintf(stdout,"%d ",array[i]);
    }
    fprintf(stdout,"\n");

    return 0;
}
