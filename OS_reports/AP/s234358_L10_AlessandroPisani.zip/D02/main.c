#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include <sys/types.h>

int n;
int global=1;
pthread_mutex_t m;
int level=0;
int *array;
void *tree_r();
int main(int argc, char **argv)
{
    setbuf(stdout,0);
    if(argc!=2){
       fprintf(stderr, "Error in the command line\n");
       exit(EXIT_FAILURE);
    }
    int *vec;
    vec=(int *)malloc(n*sizeof(int));
    if(vec==NULL){
       fprintf(stderr, "Error in the malloc\n");
       exit(EXIT_FAILURE);
    }
    n= atoi(argv[1]);
    pthread_mutex_init(&m, NULL);
    array=(int *)malloc(pow(2,n+1)*sizeof(int));
    if(array==NULL){
       fprintf(stderr, "Error in the malloc\n");
       exit(EXIT_FAILURE);
    }
    array[0]=global;
    tree_r();
    int mm=n-1;
    for(int i=pow(2,n+1)-1;i>pow(2,n)-1;i--){

       vec[mm]=i;
       for(int j=array[i-1];j!=1;j=array[j-1]){
          mm--;
          vec[mm]=j;
       }
       mm=n-1;
       printf("Process Tree: ");
       fprintf(stdout,"1 ");
       for(int k=0;k<n;k++){
          fprintf(stdout,"%d ",vec[k]);
       }
       printf("\n");
    }
    pthread_mutex_destroy(&m);

    return 0;
}

void *tree_r(){
    pthread_t tidL, tidR;

    if(global>=pow(2,n)){
       pthread_exit(NULL);
    }

    //CS
    pthread_mutex_lock(&m);
    array[global*2-1]=global;
    array[global*2]=global;
    global++;
    pthread_create(&tidL,NULL,tree_r,NULL);
    pthread_create(&tidR,NULL,tree_r,NULL);
    pthread_mutex_unlock(&m);
    //END of CS
    pthread_join(tidR,NULL);
    pthread_join(tidL,NULL);
    return NULL;
}

