#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include <sys/types.h>
#include <semaphore.h>
#include <unistd.h>

int account1=10000;
int account2=10000;
int counter=0;
pthread_mutex_t mutex;
void *banking(void *num);
int main()
{
    int n;
    fprintf(stdout,"Please enter the number of transactions you want to execute:\n");
    fscanf(stdin,"%d",&n);
    pthread_t tid2, tid1;
    pthread_mutex_init(&mutex, NULL);
    int *a,*b;
    a=malloc(sizeof(int));
    b=malloc(sizeof(int));
    *a=1;
    *b=2;
    for(int i=0;i<n;i++){
           pthread_create(&tid1,NULL,(void *)banking,(void *)a);
    pthread_create(&tid2,NULL,(void *)banking,(void *)b);
    pthread_join(tid1,NULL);
    pthread_join(tid2,NULL);
    }

    pthread_mutex_destroy(&mutex);
    return 0;
}
void *banking(void *num){
  int *numero = (int *)num;
  int number = *numero;
  char acc[8+1];
  //char acc3[8+1];
  int r,r2,r3;

  printf("thread %d starts routine\n",number);

  srand(time(NULL));
  r = ( rand() % 8 ) + 1;

  sleep(r);

  sprintf(acc,"account%d",number);

  //CS READ
  pthread_mutex_lock(&mutex);
  fprintf(stdout,"thread %d reads account%d\n",number,number);
  if(number==1){
     fprintf(stdout,"read value is: %d\n",account1);
  }else{
     fprintf(stdout,"read value is: %d\n",account2);
  }
  pthread_mutex_unlock(&mutex);

  r2 = ( rand() % 4 ) + 1;
  sleep(r2);

  r3= 1000 + ( rand() % 4000 ) + 1;
  sprintf(acc,"account%d",3-number);
  //CS MOVE
  pthread_mutex_lock(&mutex);
  fprintf(stdout,"thread %d moves money from account%d to account%d \n",number,number,3-number);
  if(number==1){
    account1-=r3;
    account2+=r3;
    fprintf(stdout,"money in account%d: %d\tmoney in account%d: %d\n",number,account1,3-number,account2);
  }else{
    account1+=r3;
    account2-=r3;
    fprintf(stdout,"money in account%d: %d\tmoney in account%d: %d\n",number,account2,3-number,account1);
  }
  pthread_mutex_unlock(&mutex);

pthread_exit(NULL);
}
