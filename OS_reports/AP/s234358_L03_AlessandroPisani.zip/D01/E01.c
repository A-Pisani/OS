#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    if(argc!=2){
       fprintf(stderr,"Wrong number of parameters\n");
       exit(1);
    }
    int n, i;
    pid_t pid, pid1;
    int count=0;

    n=atoi(argv[1]);
    for(i=1;i<=n;i++){
      if(i%2==0){
        pid=fork();
        if(pid!=0){
            pid1=fork();
            if(pid1!=0)
               return 0;
      }else{
        pid=fork();
        if(pid!=0){
             return 0;
        }
      }
    }
    fprintf(stdout,"\nProcess %d :", getpid());
    return 0;
}

