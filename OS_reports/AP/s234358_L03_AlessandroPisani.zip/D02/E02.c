#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    if(argc!=2){
       fprintf(stderr,"Wrong number of parameters\n");
       exit(1);
    }
    int n, i;
    pid_t pid, pid1;
    pid_t vector[100];
    int count=0;

    n=atoi(argv[1]);
    for(i=1;i<=n;i++){
      if(i%2==0){
        pid=fork();
        if(pid!=0){
            pid1=fork();
            if(pid1!=0)
               return 0;
      }else{
        vector[count++]=getpid();
        pid=fork();
        if(pid!=0){
             return 0;
        }
        vector[count++]=getpid();
      }
    }
    fprintf(stdout,"\nProcess %d :", getpid());
    for(i=0;i<count-1;i++){
        fprintf(stdout,"%d %d ",i+1, vector[i]);
    }
    fprintf(stdout,"\n");
    return 0;
}

